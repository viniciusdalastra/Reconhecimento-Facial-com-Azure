﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Model
{
    class ModelPessoa
    {
        public int codigo { get; set; }
        public string nome { get; set; }
        public int codigo_universitario { get; set; }
    }
}
