﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Model
{
    class ModelPessoaIdentificador
    {
        public int codigo { get; set; }
        public String identificador { get; set; }

        public int codigo_pessoa { get; set; }
        public string nome_pessoa { get; set; }
        public int codigo_universitario_pessoa { get; set; }
    }
}
