﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    static class Program
    {
        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //verificar na Classe Conexão para conectar no mesmo banco de dados
            //Reconhecedor
            Application.Run(new Form1());
            //Manutencao 
            //Application.Run(new FormManutencao());
        }
    }
}
